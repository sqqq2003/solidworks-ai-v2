# PR#60 f15 envelope retest gap table (cb7aaa9)

- stamp: `20261026_f15_cb7aaa9`
- HEAD: base `4344f22` + overlay PR#60 tip `cb7aaa9`
- overall: **pass**

| id | status | expect | got | err mm | saved? | contour_open? |
|---|---|---|---|---|---|---|
| f15 | pass | [54.97, 10.0, 10.0] | [54.937834358836255, 9.999999999997653, 9.999999999997653] | [-0.0322, -0.0, -0.0] | yes | no |
| f09 | pass | [166.0, 28.0, 28.0] | [166.0, 28.000000000053245, 28.000000000053245] | [0.0, 0.0, 0.0] | yes | no |
| f19 | pass | [385.0, 15.0, 15.0] | [385.0, 15.004449316559779, 15.004449316559779] | [0.0, 0.0044, 0.0044] | yes | no |
| f11 | pass | [75.0, 19.63, 17.0] | [75.0, 19.629909152447276, 17.0] | [0.0, -0.0001, 0.0] | yes | no |

Notes:
- Prior tip b6d1232: f15 envelope 56.42 vs 54.97 aborted save.
- This tip cb7aaa9: f15 saved + measured within tol (~-0.03 mm length).
