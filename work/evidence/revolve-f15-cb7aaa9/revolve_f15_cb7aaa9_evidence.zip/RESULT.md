# PR#60 f15 cb7aaa9 DDD live RESULT

- stamp: 20261026_f15_cb7aaa9
- HEAD base: `4344f222a2070d0f79082d219377e840f06ca30f` (PR#57 COM tip, detached)
- PR#60 tip overlay: `cb7aaa9341d3d8419a8494ec102f128e134c044e`
  - files: src/turned_generate.py, src/turned_part.py, tests/test_revolve_contour_closure.py
- offline: tests/test_revolve_contour_closure.py 12/12 pass
- OUT: D:\工程\钣金导入\lxy_revolve_f15_cb7aaa9
- Docs: C:\Users\yue\Documents\lxy_revolve_f15_cb7aaa9
- overall: **pass**

## f15 (focus)
- status: **pass**
- expect: [54.97, 10.0, 10.0]
- got: [54.937834358836255, 9.999999999997653, 9.999999999997653]
- dim_error_mm: [-0.0322, -0.0, -0.0]
- saved SLDPRT: yes (115047 bytes)
- prior fail: envelope 56.42 vs 54.97 (b6d1232)

## All cases

| id | status | got | err mm | saved |
|---|---|---|---|---|
| f15 | **pass** | [54.937834358836255, 9.999999999997653, 9.999999999997653] | [-0.0322, -0.0, -0.0] | yes |
| f09 | **pass** | [166.0, 28.000000000053245, 28.000000000053245] | [0.0, 0.0, 0.0] | yes |
| f19 | **pass** | [385.0, 15.004449316559779, 15.004449316559779] | [0.0, 0.0044, 0.0044] | yes |
| f11 | **pass** | [75.0, 19.629909152447276, 17.0] | [0.0, -0.0001, 0.0] | yes |

## Limits
- No git push; desktop repo dirty with PR#60 overlay on detached 4344f22.
- Initial generate-pass left docs unmeasured (OpenDoc6 tuple); separate measure pass fixed dims.
