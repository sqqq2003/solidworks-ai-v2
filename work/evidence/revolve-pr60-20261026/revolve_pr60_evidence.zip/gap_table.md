# PR#60 revolve gap table (DDD live)

- stamp: `20261026_150155`
- HEAD: base `4344f22` + overlay PR#60 tip `b6d1232`
- overall: **partial**

| id | status | expect | got | err mm | contour_open? |
|---|---|---|---|---|---|
| f09 | pass | [166.0, 28.0, 28.0] | [167.32826234020072, 28.000000000016435, 28.000000000016435] | [1.3283, 0.0, 0.0] | no |
| f15 | partial_contour_ok_envelope_fail | [54.97, 10.0, 10.0] | [56.42, 10.0, 10.0] | [1.45, 0.0, 0.0] | no |
| f19 | pass | [385.0, 15.0, 15.0] | [385.0, 15.004449316559779, 15.004449316559779] | [0.0, 0.0044, 0.0044] | no |
| f11 | pass | [75.0, 19.63, 17.0] | [75.0, 19.629909152447276, 17.0] | [0.0, -0.0001, 0.0] | no |

Notes:
- Prior PR#57: f09/f15/f19 failed contour-open; f11 PASS.
- This run: no contour-open. f15 fails later envelope gate.
