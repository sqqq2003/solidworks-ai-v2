# HANDOFF — PR#60 revolve DDD live

## For parent / Codex
- OUT: D:\工程\钣金导入\lxy_revolve_pr60_20261026_150155
- HEAD: 4344f22 + overlay b6d1232 (CreateArc + seal_revolve_contour)
- overall **partial**
- Contour-open: **gone** on f09/f15/f19
- f09/f19/f11 dims **pass**; f15 **partial** (envelope 56.42 vs 54.97, no file)
- Next for f15: inspect seal/arc vs plan length; do not reopen contour-open as primary.

## SW leftovers
- Embedding orphan PID 52620 still present (unreachable COM)
- Owned sessions ExitApp when idle 0-doc
