# PR#60 revolve contour closure — DDD live RESULT

- stamp: 20261026_150155
- machine: DDD (53b729f9-00c0-4608-a10e-6cf246cf0a4e)
- HEAD base: `4344f222a2070d0f79082d219377e840f06ca30f` (PR#57 COM tip, detached)
- PR#60 tip overlay: `b6d123200f216f194712db925ab0f3bf9dbd57fc`
  - files: src/turned_generate.py, src/turned_part.py, tests/test_revolve_contour_closure.py
- offline: tests/test_revolve_contour_closure.py 8/8 pass
- OUT: D:\工程\钣金导入\lxy_revolve_pr60_20261026_150155
- Docs copy: C:\Users\yue\Documents\lxy_revolve_pr60_20261026_150155
- SW policy: CloseDoc-only; ExitApp only when doc_count==0. No taskkill.
- Embedding orphan PID 52620 left (GetActiveObject+ROT unavailable).

## Status (honest)

| id | status | dims | contour_open |
|---|---|---|---|
| f09 | **pass** | 167.33x28x28 vs 166x28x28 (dL~+1.33 mm, within 2%) | no |
| f15 | **partial_contour_ok_envelope_fail** | envelope 56.42x10x10 vs 54.97x10x10; save aborted; no SLDPRT | no |
| f19 | **pass** | 385.00x15.004x15.004 vs 385x15x15 | no |
| f11 | **pass** (hex regression) | 75.00x19.630x17.00 vs 75x19.63x17 | n/a |

**Overall: partial** — PR#60 CreateArc+seal fixed prior contour-open on f09/f15/f19. f15 still no part because envelope length exceeds tol (~+1.45 mm).

## Artifacts
- chejian/f09_*.SLDPRT, f19_*.SLDPRT, f11_*.SLDPRT
- accept_revolve.json, accept_measure.json, gap_table.md, HANDOFF.md
- gen_*_stdout.txt, measure_stdout.txt, probe_f09*

## Limits
- No git push; desktop repo dirty with PR#60 overlay on detached 4344f22.
- f15 length oversize after seal not fully diagnosed.
